import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-main-content',
  imports: [CommonModule],
  templateUrl: './main-content.component.html',
  styleUrl: './main-content.component.css'
})
export class MainContentComponent {

  cards = [
  { title: 'Card 1', content: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit.' },
  { title: 'Card 2', content: 'Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.' },
  { title: 'Card 3', content: 'Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris.' },
  { title: 'Card 4', content: 'Duis aute irure dolor in reprehenderit in voluptate velit esse cillum.' },
  { title: 'Card 5', content: 'Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia.' },
  { title: 'Card 6', content: 'Deserunt mollit anim id est laborum.' }
];

}
