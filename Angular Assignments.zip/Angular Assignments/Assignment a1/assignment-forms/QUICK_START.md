# Quick Start Guide

## Prerequisites
- Node.js v25.3.0 (installed)
- Angular CLI 15.2.11 (installed)
- npm 11.6.2 (installed)

## Starting the Application

### Step 1: Open Terminal 1 - Start JSON Server
```bash
cd "c:\Users\muhshaik\Desktop\Angular Assignments\Assignment a1\assignment-forms"
npx json-server --watch db.json --port 3001
```

Wait for message: "Watching db.json..."

### Step 2: Open Terminal 2 - Start Angular Dev Server
```bash
cd "c:\Users\muhshaik\Desktop\Angular Assignments\Assignment a1\assignment-forms"
ng serve --port 4201
```

Wait for message: "Application bundle generation complete. [X.XXs]"

### Step 3: Open Application
Navigate to: **http://localhost:4201**

---

## Login Credentials (Pre-loaded)
- **Email**: admin@gmail.com
- **Password**: Admin@123

---

## What Works

### ✓ Login Form
- Enter credentials and submit
- See success/error messages
- Navigate to register if not found

### ✓ Register Form
- Fill in all fields with validation
- See dynamic error messages
- Email must be unique (async validation)
- Data persists in db.json

### ✓ Form Validation
- Required fields enforce input
- Email format validation
- Password minimum length (6)
- Role selection required
- Instant feedback as you type

### ✓ Dynamic Error Messages
- Red error messages appear below each field
- Clear on successful input
- Different messages for different errors

---

## Key Features

1. **Reactive Forms** - FormGroup and FormControl
2. **Custom Validators** - validEmail() and requiredRole()
3. **Async Validators** - Email uniqueness check
4. **RxJS Operators** - debounceTime, distinctUntilChanged, switchMap, map
5. **HTTP Integration** - GET/POST to json-server
6. **Dynamic Styling** - Error states, success messages, animations
7. **Responsive Design** - Works on mobile and desktop

---

## Troubleshooting

### Port 3001 Already in Use
```bash
# Kill the process using port 3001
netstat -ano | findstr :3001
taskkill /PID <PID> /F

# Or change port in auth.service.ts and run:
npx json-server --watch db.json --port 3002
```

### Port 4201 Already in Use
```bash
ng serve --port 4202
# Then visit http://localhost:4202
```

### Clear Build Cache
```bash
ng cache clean
ng serve --port 4201
```

---

## Testing Checklist

- [ ] Load login page
- [ ] Try invalid email format
- [ ] Try password less than 6 characters
- [ ] Login with admin@gmail.com / Admin@123
- [ ] Click Register button
- [ ] Try duplicate email on register
- [ ] Register with new valid credentials
- [ ] Verify db.json has new user
- [ ] Login with newly registered user

---

## File Locations

| File | Purpose |
|------|---------|
| [src/app/component/login/](src/app/component/login/) | Login form component |
| [src/app/component/register/](src/app/component/register/) | Registration form component |
| [src/app/services/auth.service.ts](src/app/services/auth.service.ts) | HTTP service for API calls |
| [src/app/validators/custom-validators.ts](src/app/validators/custom-validators.ts) | Custom form validators |
| [db.json](db.json) | JSON database (stores users) |

---

## Important Notes

1. **Keep both terminals running** - JSON Server AND Angular Dev Server
2. **Check browser console** - For any JavaScript errors
3. **Check Network tab** - To see API calls to localhost:3001
4. **Hot reload** - Changes to code auto-refresh in browser
5. **Form state** - Submit button disabled when form invalid

---

## Support

If the app doesn't start:
1. Check both terminals are running
2. Verify no port conflicts (3001, 4201)
3. Clear npm cache: `npm cache clean --force`
4. Reinstall: `npm install`
5. Check file paths are correct
