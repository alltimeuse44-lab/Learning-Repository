import { Component, OnDestroy, OnInit } from '@angular/core';
import { FormBuilder, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { debounceTime, distinctUntilChanged, Subject, takeUntil, tap } from 'rxjs';
import { AuthService } from '../../services/auth.service';
import { CustomValidators } from '../../validators/custom-validators';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [FormsModule, ReactiveFormsModule, CommonModule],
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
})
export class LoginComponent implements OnInit, OnDestroy {
  submitting = false;
  message = '';
  private destroy$ = new Subject<void>();

  form = this.fb.group({
    email: ['', [Validators.required, CustomValidators.validEmail()]],
    password: ['', [Validators.required, Validators.minLength(6)]],
  });

  constructor(private fb: FormBuilder, private auth: AuthService, private router: Router) {}

  ngOnInit(): void {
    // Show errors dynamically as user types (RxJS operators)
    this.form.valueChanges
      .pipe(
        debounceTime(150),
        distinctUntilChanged(),
        tap(() => (this.message = '')),
        takeUntil(this.destroy$)
      )
      .subscribe();
  }

  get f() {
    return this.form.controls;
  }

  submit() {
    if (this.form.invalid) {
      this.form.markAllAsTouched();
      return;
    }
    this.submitting = true;
    const { email, password } = this.form.value as { email: string; password: string };

    this.auth.login(email.trim(), password).subscribe(user => {
      this.submitting = false;
      if (user) {
        this.message = `Welcome, ${user.name}!`;
        // Navigate to a protected page if you have one; for demo we stay
      } else {
        this.message = 'User not found or wrong password. Please register.';
        // Optionally route directly:
        // this.router.navigate(['/register'], { queryParams: { email } });
      }
    });
  }

  goToRegister() {
    this.router.navigate(['/register'], { queryParams: { email: this.f.email.value } });
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }
}