import { Component, OnDestroy, OnInit } from '@angular/core';
import { AbstractControl, AsyncValidatorFn, FormBuilder, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { debounceTime, distinctUntilChanged, map, of, Subject, switchMap, takeUntil, tap } from 'rxjs';
import { AuthService, User } from '../../services/auth.service';
import { CustomValidators } from '../../validators/custom-validators';

@Component({
  selector: 'app-register',
  standalone: true,
  imports: [FormsModule, ReactiveFormsModule, CommonModule],
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css'],
})
export class RegisterComponent implements OnInit, OnDestroy {
  submitting = false;
  message = '';
  roles = ['admin', 'call center', 'tester', 'field agent', 'citizen'];

  private destroy$ = new Subject<void>();

  form = this.fb.group({
    name: ['', [Validators.required, Validators.minLength(2)]],
    email: [
      '',
      [Validators.required, CustomValidators.validEmail()],
      [this.emailUniqueValidator()]
    ],
    password: ['', [Validators.required, Validators.minLength(6)]],
    role: ['', [CustomValidators.requiredRole()]],
  });

  constructor(
    private fb: FormBuilder,
    private auth: AuthService,
    private router: Router,
    private route: ActivatedRoute
  ) {}

  ngOnInit(): void {
    // Pre-fill email if coming from login
    const qEmail = this.route.snapshot.queryParamMap.get('email');
    if (qEmail) this.form.patchValue({ email: qEmail });

    // Dynamic messages
    this.form.valueChanges
      .pipe(
        debounceTime(150),
        distinctUntilChanged(),
        tap(() => (this.message = '')),
        takeUntil(this.destroy$)
      )
      .subscribe();
  }

  get f() {
    return this.form.controls;
  }

  submit() {
    if (this.form.invalid) {
      this.form.markAllAsTouched();
      return;
    }
    this.submitting = true;
    const user = this.form.value as User;

    // trim inputs
    user.email = user.email.trim();
    user.name = user.name.trim();
    user.role = user.role.trim();

    this.auth.register(user).subscribe(created => {
      this.submitting = false;
      if (created && created.id) {
        this.message = 'Registration successful! You can now log in.';
        // Redirect after a moment
        setTimeout(() => this.router.navigate(['/login'], { queryParams: { email: user.email } }), 800);
      } else {
        this.message = 'Registration failed. Please try again.';
      }
    });
  }

  /** Async validator for unique email */
  private emailUniqueValidator(): AsyncValidatorFn {
    return (control: AbstractControl) => {
      const raw = (control.value || '').trim();
      if (!raw) return of(null);
      return of(raw).pipe(
        debounceTime(300),
        switchMap(email => this.auth.emailExists(email)),
        map(exists => (exists ? { emailTaken: true } : null))
      );
    };
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }
}