import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { catchError, map, of } from 'rxjs';

export interface User {
  id?: number;
  name: string;
  email: string;
  password: string;
  role: string;
}

@Injectable({ providedIn: 'root' })
export class AuthService {
  private baseUrl = 'http://localhost:3002';

  constructor(private http: HttpClient) {}

  /** Check login by matching email+password */
  login(email: string, password: string) {
    const params = new HttpParams().set('email', email).set('password', password);
    return this.http.get<User[]>(`${this.baseUrl}/users`, { params }).pipe(
      map(users => users.length ? users[0] : null),
      catchError(() => of(null))
    );
  }

  /** Register user (returns created user) */
  register(user: User) {
    return this.http.post<User>(`${this.baseUrl}/users`, user).pipe(
      catchError(() => of(null))
    );
  }

  /** Check if email already exists (used by async validator) */
  emailExists(email: string) {
    const params = new HttpParams().set('email', email);
    return this.http.get<User[]>(`${this.baseUrl}/users`, { params }).pipe(
      map(users => users.length > 0),
      catchError(() => of(false))
    );
  }
}