import { AbstractControl, ValidationErrors, ValidatorFn } from '@angular/forms';

export class CustomValidators {
  // Simple email pattern (good enough for UI validation)
  static emailPattern =
    /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/i;

  static validEmail(): ValidatorFn {
    return (control: AbstractControl): ValidationErrors | null => {
      const value = (control.value || '').trim();
      if (!value) return null; // handled by required
      return CustomValidators.emailPattern.test(value)
        ? null
        : { emailInvalid: true };
    };
  }

  static requiredRole(): ValidatorFn {
    return (control: AbstractControl): ValidationErrors | null => {
      const value = (control.value || '').toString().trim();
      // role must be selected from dropdown; empty/placeholder invalid
      if (!value) return { roleRequired: true };
      // optionally prevent 'Select...' placeholder
      if (value === 'select') return { roleRequired: true };
      return null;
    };
  }
}