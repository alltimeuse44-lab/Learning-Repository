import { Component } from '@angular/core';
import { FormGroup, FormControl, Validators, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { UserService } from '../user.service';
import { RegisterComponent } from '../register/register';
import { RouterLink } from "@angular/router";

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [ReactiveFormsModule, CommonModule, RouterLink],
  templateUrl: './login.html',
  styleUrl: './login.css'
})

export class LoginComponent {
  showRegister = false;
  message = '';

  loginForm = new FormGroup({
    email: new FormControl('', [Validators.required, Validators.email]),
    password: new FormControl('', Validators.required)
  });

  constructor(private userService: UserService) {}

  login() {
    const { email, password } = this.loginForm.value;

    if (!this.userService.isUserRegistered(email!)) {
      this.showRegister = true;
      this.message = 'User not registered. Please register.';
      return;
    }

    if (this.userService.loginUser(email!, password!)) {
      this.message = 'Login successful ';
    } else {
      this.message = 'Invalid credentials ';
    }
  }
}

