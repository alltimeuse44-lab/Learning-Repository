import { Component } from '@angular/core';
import { FormGroup, FormControl, Validators, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { UserService } from '../user.service';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-register',
  standalone: true,
  imports: [ReactiveFormsModule, CommonModule, RouterLink],
  templateUrl: './register.html',
  styleUrl: './register.css'
})
export class RegisterComponent {
  successMsg = '';
  roles = ['Admin', 'Call Center', 'Tester', 'User'];

  registerForm = new FormGroup({
    name: new FormControl('', Validators.required),
    email: new FormControl('', [Validators.required, Validators.email]),
    password: new FormControl('', Validators.required),
    role: new FormControl('User', Validators.required)
  });

  constructor(private userService: UserService) {}

  register() {
    if (this.registerForm.invalid) {
      return;
    }

    this.userService.registerUser(this.registerForm.value);
    localStorage.setItem('temp', JSON.stringify(this.registerForm.value));
    this.successMsg = 'Registration successful';
    this.registerForm.reset({ role: 'User' });
  }
}
