import { Injectable } from '@angular/core';

@Injectable({ providedIn: 'root' })
export class UserService {
  private storageKey = 'users';

  private getStoredUsers(): any[] {
    return JSON.parse(localStorage.getItem(this.storageKey) || '[]');
  }

  isUserRegistered(email: string): boolean {
    const users = this.getStoredUsers();
    return users.some(user => user.email === email);
  }

  registerUser(userData: any) {
    const users = this.getStoredUsers();
    users.push(userData);
    localStorage.setItem(this.storageKey, JSON.stringify(users));
    console.log('Stored Users:', users);
  }

  loginUser(email: string, password: string): boolean {
    const users = this.getStoredUsers();
    return users.some(
      user => user.email === email && user.password === password
    );
  }
}