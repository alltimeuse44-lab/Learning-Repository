import { Component, signal } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { Table } from './shared/table/table';
import { ScrivaniaItalia } from './scrivania-italia/scrivania-italia';
import { ScrivaniaEstero } from "./scrivania-estero/scrivania-estero";

@Component({
  selector: 'app-root',
  imports: [RouterOutlet, Table, ScrivaniaItalia, ScrivaniaEstero],
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App {
  protected readonly title = signal('component-communication');
}
