import { Component } from '@angular/core';
import { User } from '../shared/user';

@Component({
  selector: 'app-scrivania-estero',
  imports: [],
  templateUrl: './scrivania-estero.html',
  styleUrl: './scrivania-estero.scss',
})
export class ScrivaniaEstero {

  userDetails: any;

  constructor(private user: User){
    this.user.$user.subscribe(user=> {
      this.userDetails = user;
    });
  }
}
