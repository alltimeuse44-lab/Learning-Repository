import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Table } from '../shared/table/table';


@Component({
  selector: 'app-scrivania-italia',
  imports: [CommonModule, Table],
  templateUrl: './scrivania-italia.html',
  styleUrl: './scrivania-italia.scss',
})
export class ScrivaniaItalia {
  
selectedRow: any;

  columns = ['id', 'customer', 'amount', 'status'];

  tableData = [
    { id: 1, customer: 'ABC Spa', amount: 1200, status: 'OPEN' },
    { id: 2, customer: 'XYZ Srl', amount: 950, status: 'CLOSED' },
    { id: 3, customer: 'CDF Rfk', amount: 1100, status: 'CLOSED' }
  ];

  onRowSelected(row: any) {
    this.selectedRow = row;
  }

}
