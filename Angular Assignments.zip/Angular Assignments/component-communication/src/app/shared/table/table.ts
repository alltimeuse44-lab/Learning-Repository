import { Component, Output, Input, EventEmitter ,Pipe } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-table',
  imports: [CommonModule],
  templateUrl: './table.html',
  styleUrl: './table.scss',
})
export class Table {

  @Input() columns: string[] = [];
  @Input() data: any[] = [];

  @Output() rowClicked = new EventEmitter<any>();

  sortColumn = '';
  sortAsc = true;

  onSort(column: string) {
    this.sortAsc = this.sortColumn === column ? !this.sortAsc : true;
    this.sortColumn = column;

    this.data.sort((a, b) => {
      if (a[column] < b[column]) return this.sortAsc ? -1 : 1;
      if (a[column] > b[column]) return this.sortAsc ? 1 : -1;
      return 0;
    });
  }

  onRowClick(row: any) {
    this.rowClicked.emit(row);
  }
}
