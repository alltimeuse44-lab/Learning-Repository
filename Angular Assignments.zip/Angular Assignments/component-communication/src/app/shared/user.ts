import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class User {
  
  userSubject = new Subject<any>();
  $user = this.userSubject.asObservable();

  setUser(user: any){
    this.userSubject.next(user);
  }
}
