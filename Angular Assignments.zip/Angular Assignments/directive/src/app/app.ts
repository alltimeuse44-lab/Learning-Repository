import { Component } from '@angular/core';
import { Presentazioni } from './presentazioni/presentazioni';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [Presentazioni],
  template: `<app-presentazioni />`,
})
export class App {}
