import { Directive, ElementRef, HostListener, Renderer2 } from '@angular/core';

@Directive({ 
  selector: '[appCollapse]',
  standalone: true,
  exportAs: 'appCollapse'
})
export class CollapseDirective {
  constructor(private el: ElementRef, private renderer: Renderer2) {}

  @HostListener('document:click', ['$event.target'])
  onClickOutside(target: EventTarget | null) {
    if (!this.el.nativeElement.contains(target)) {
      this.renderer.addClass(this.el.nativeElement, 'search--collapsed');
    }
  }

  expand() {
    this.renderer.removeClass(this.el.nativeElement, 'search--collapsed');
  }
}
