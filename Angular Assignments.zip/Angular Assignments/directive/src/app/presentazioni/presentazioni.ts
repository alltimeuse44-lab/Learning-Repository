import { Component, ViewChild } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CollapseDirective } from '../directives/collapse.directive';
import { IfDirective } from '../directives/if.directive';

@Component({
  selector: 'app-presentazioni',
  standalone: true,
  imports: [FormsModule, CollapseDirective, IfDirective],
  templateUrl: './presentazioni.html',
  styleUrl: './presentazioni.scss',
})
export class Presentazioni {
  @ViewChild(CollapseDirective) collapseDir!: CollapseDirective;

  searchQuery = '';
  showArchived = false;

  presentations = [
    { id: 1, title: 'Q1 Financial Report', author: 'Mario Rossi', status: 'Active' },
    { id: 2, title: 'Product Roadmap 2024', author: 'Giulia Bianchi', status: 'Active' },
    { id: 3, title: 'Market Analysis', author: 'Luca Verdi', status: 'Archived' },
    { id: 4, title: 'Team Onboarding', author: 'Sara Neri', status: 'Draft' },
    { id: 5, title: 'Annual Review 2023', author: 'Marco Esposito', status: 'Archived' },
  ];

  get filtered() {
    return this.presentations.filter(p =>
      p.title.toLowerCase().includes(this.searchQuery.toLowerCase()) ||
      p.author.toLowerCase().includes(this.searchQuery.toLowerCase())
    );
  }

  onSearchClick(event: MouseEvent) {
    event.stopPropagation();
    this.collapseDir.expand();
  }
}
