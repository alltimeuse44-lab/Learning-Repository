import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { CapitalizePipe } from './capitalize-pipe';
import { NumberFormatPipe } from './number-format-pipe';

@Component({
  selector: 'app-root',
  imports: [CommonModule, CapitalizePipe, NumberFormatPipe],
  templateUrl: './app.html',
  styleUrl: './app.scss'
})

export class App {
  userName = 'suhel';
  today = new Date();
  salary = 2500;
  prices = [1234, 56789, 98765];
  number = 1000000
}
