import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'capitalize',
})
export class CapitalizePipe implements PipeTransform {
  transform(name: string): string {
    return name.charAt(0).toUpperCase() + name.slice(1);
  }
}
