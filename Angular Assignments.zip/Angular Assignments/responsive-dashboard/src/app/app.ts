import { Component } from '@angular/core';
import { NgClass } from '@angular/common';

@Component({
  selector: 'app-root',
  imports: [NgClass],
  templateUrl: './app.html',
  styleUrl: './app.scss',
})
export class App {
  menuOpen = false;

  items = ['Home', 'Analytics', 'Users', 'Projects', 'Settings'];
}
