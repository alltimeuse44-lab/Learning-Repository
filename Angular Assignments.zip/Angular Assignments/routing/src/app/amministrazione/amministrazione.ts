import { Component } from '@angular/core';

@Component({
  selector: 'app-amministrazione',
  imports: [],
  templateUrl: './amministrazione.html',
  styleUrl: './amministrazione.css'
})
export class Amministrazione {}
