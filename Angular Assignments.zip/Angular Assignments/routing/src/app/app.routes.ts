import { Routes } from '@angular/router';
import { authGuard } from './auth/auth-guard';

export const routes: Routes = [
  {
    path: '',
    redirectTo: 'dashboard',
    pathMatch: 'full'
  },
  {
    path: 'dashboard',
    loadComponent: () => import('./dashboard/dashboard')
      .then(c => c.Dashboard)
  },
  {
    path: 'lavorazioni',
    loadChildren: () => import('./lavorazioni/lavorazioni')
      .then(m => m.LAVORAZIONI_ROUTES)
  },
  {
    path: 'amministrazione',
    loadComponent: () => import('./amministrazione/amministrazione')
      .then(c => c.Amministrazione)
  },
  {
    path: '**',
    redirectTo: 'dashboard'
  }
];
