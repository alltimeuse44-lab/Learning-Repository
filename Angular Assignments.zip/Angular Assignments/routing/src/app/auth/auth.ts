import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class Auth {
  role = 'admin';
  userName = 'user1'

  isAdmin(){
    return this.role === 'admin';
  }
}
