import { Component } from '@angular/core';
import { Auth } from '../auth/auth';

@Component({
  selector: 'app-dashboard',
  imports: [],
  templateUrl: './dashboard.html',
  styleUrls: ['./dashboard.css'],
})

export class Dashboard {

  user: string;
  role: string;

  constructor(private auth: Auth) {
    this.user = this.auth.userName;
    this.role = this.auth.role;
  }
}
