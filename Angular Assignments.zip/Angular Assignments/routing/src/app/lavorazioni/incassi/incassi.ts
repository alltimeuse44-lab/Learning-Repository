import { Component } from '@angular/core';

@Component({
  selector: 'app-incassi',
  imports: [],
  templateUrl: './incassi.html',
  styleUrl: './incassi.css',
})
export class Incassi {}
