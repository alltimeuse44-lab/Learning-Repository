import { Routes } from '@angular/router';
import { authGuard } from '../auth/auth-guard';

export const LAVORAZIONI_ROUTES: Routes = [
  {
    path: 'italia',
    loadComponent: () =>
      import('./scrivania-italia/scrivania-italia')
        .then(c => c.ScrivaniaItalia),
    canActivate: [authGuard]
  },
  {
    path: 'estero',
    loadComponent: () =>
      import('./scrivania-estero/scrivania-estero')
        .then(c => c.ScrivaniaEstero),
    canActivate: [authGuard]
  },
  {
    path: 'incassi',
    loadComponent: () =>
      import('./incassi/incassi')
        .then(c => c.Incassi),
    canActivate: [authGuard]
  }
];
