import { Component } from '@angular/core';

@Component({
  selector: 'app-scrivania-estero',
  imports: [],
  templateUrl: './scrivania-estero.html',
  styleUrl: './scrivania-estero.css',
})
export class ScrivaniaEstero {}
