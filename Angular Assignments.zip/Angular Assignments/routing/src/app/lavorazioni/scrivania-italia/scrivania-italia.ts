import { Component } from '@angular/core';

@Component({
  selector: 'app-scrivania-italia',
  imports: [],
  templateUrl: './scrivania-italia.html',
  styleUrl: './scrivania-italia.css',
})
export class ScrivaniaItalia {}
