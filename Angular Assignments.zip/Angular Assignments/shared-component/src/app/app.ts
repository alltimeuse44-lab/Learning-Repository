import { Component, inject, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FooterComponent } from './shared/footer.component/footer.component';
import { LoaderComponent } from './shared/loader.component/loader.component';
import { Notification } from './shared/notification';
import { Loader } from './shared/loader';

@Component({
  selector: 'app-root',
  imports: [CommonModule, FooterComponent, LoaderComponent],
  templateUrl: './app.html',
  styleUrl: './app.scss',
})
export class App implements OnInit {
  notificationService = inject(Notification);
  loaderService = inject(Loader);

  error$ = this.notificationService.error$;

  ngOnInit() {

    if (!localStorage.getItem('user')) {
      localStorage.setItem('user', JSON.stringify({ name: 'suhel', email: 'suhel@gmail.com' }));
    }
  }

  simulateRequest() {
    console.log('Simulating API request...');
    this.loaderService.show();
    setTimeout(() => {
      this.loaderService.hide();
      console.log('Request complete');
    }, 2000);
  }

  triggerError() {
    this.notificationService.showError('Something went wrong! Please try again.');
  }

  clearError() {
    this.notificationService.clear();
  }
}
