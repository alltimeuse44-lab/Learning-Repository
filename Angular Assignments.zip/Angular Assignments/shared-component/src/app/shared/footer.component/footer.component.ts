import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-footer',
  imports: [CommonModule],
  templateUrl: './footer.component.html',
  styleUrl: './footer.component.scss',
})
export class FooterComponent implements OnInit {
  user: { name: string; email: string } | null = null;

  ngOnInit() {
    const saved = localStorage.getItem('user');
    if (saved) {
      this.user = JSON.parse(saved);
      console.log('Footer user:', this.user);
    }
  }
}
