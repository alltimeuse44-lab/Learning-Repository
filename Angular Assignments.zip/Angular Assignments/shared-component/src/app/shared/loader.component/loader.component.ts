import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Loader } from '../loader';

@Component({
  selector: 'app-loader',
  imports: [CommonModule],
  templateUrl: './loader.component.html',
  styleUrl: './loader.component.scss',
})
export class LoaderComponent {
  loaderService = inject(Loader);
  loading$ = this.loaderService.loading$;
}
