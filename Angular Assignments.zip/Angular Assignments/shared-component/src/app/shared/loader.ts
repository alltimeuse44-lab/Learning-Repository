import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class Loader {
  private loadingSource = new BehaviorSubject<boolean>(false);
  loading$ = this.loadingSource.asObservable();

  show() {
    console.log('Loader: show');
    this.loadingSource.next(true);
  }

  hide() {
    console.log('Loader: hide');
    this.loadingSource.next(false);
  }
}
