import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class Notification {
  private errorSource = new BehaviorSubject<string | null>(null);
  error$ = this.errorSource.asObservable();

  showError(message: string){
    console.log('Error: ', message);
    this.errorSource.next(message);
  }

  clear(){
    this.errorSource.next(null);
  }
  
}
