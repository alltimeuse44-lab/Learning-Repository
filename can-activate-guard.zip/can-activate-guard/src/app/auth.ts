import { Injectable, signal } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class Auth {
  isLogin=signal(false);

  login(){
    this.isLogin.set(true);
  }
  logout(){
    this.isLogin.set(false);
  }
}
