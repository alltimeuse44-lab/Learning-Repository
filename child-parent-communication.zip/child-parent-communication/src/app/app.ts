import { Component, signal } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { Child } from './child/child';

@Component({
  selector: 'app-root',
  imports: [RouterOutlet, Child],
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App {
  courseName='Angular';
  count = signal(10);
  message!: string;
  receiveData(val: string){
    this.message=val;
  }

  getMessage='';
  getData(value: string){
    this.getMessage = value;
  }
}
