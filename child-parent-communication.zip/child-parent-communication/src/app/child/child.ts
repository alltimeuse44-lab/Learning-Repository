import { Component, EventEmitter, Input, output, Output, signal } from '@angular/core';

@Component({
  selector: 'app-child',
  imports: [],
  standalone: true,
  templateUrl: './child.html',
  styleUrl: './child.css',
})
export class Child {
  
  @Input()
  course='';
  num=signal<number>(0);

  @Output() greeting= new EventEmitter<string>();
  sendDataToParent(){
    this.greeting.emit("Hello parent");
  }

 msg = signal("Hi from child");
 updateMessage(){
  this.msg.set("Hi, message updated from child component");
 }
}
