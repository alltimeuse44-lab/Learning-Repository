import { Routes } from '@angular/router';
import { LoginComponent } from './components/login/login.component';
import { RegistrationComponent } from './components/registration/registration.component';
import { AdminComponent } from './components/admin/admin.component';
import { DoctorComponent } from './components/doctor/doctor.component';
import { PatientComponent } from './components/patient/patient.component';
import { AuthGuard } from './guards/auth.guard';
import { PatientAppointmentComponent } from './components/patient/patient-appointment.component';


export const routes: Routes = [
  { path: 'patient-appointment', component: PatientAppointmentComponent },
  { path: '', redirectTo: '/doctor', pathMatch: 'full' },
  { path: 'login', component: LoginComponent },
  { path: 'register', component: RegistrationComponent },
  {
    path: 'dashboard-admin',
    component: AdminComponent,
    canActivate: [AuthGuard],
    data: { roles: ['ADMIN'] }
  },
  {
    path: 'patient',
    component: PatientComponent,
    canActivate: [AuthGuard],
    data: { roles: ['PATIENT'] },
    children: [
      { path: '', loadComponent: () => import('./components/patient/patient-dashboard.component').then(m => m.PatientDashboardComponent) },
      { path: 'book', loadComponent: () => import('./components/patient/book-appointment.component').then(m => m.BookAppointmentComponent) },
      { path: 'appointments', loadComponent: () => import('./components/patient/my-appointments.component').then(m => m.MyAppointmentsComponent) },
      { path: 'profile', loadComponent: () => import('./components/patient/edit-profile.component').then(m => m.EditProfileComponent) }
    ]
  },
  {
    path: 'doctor',
    component: DoctorComponent,
    canActivate: [AuthGuard],
    data: { roles: ['DOCTOR'] },
    children: [
      { path: '', loadComponent: () => import('./components/doctor/dashboard.component').then(m => m.DashboardComponent) },
      { path: 'pending-appointments', loadComponent: () => import('./components/doctor/pending-appointments.component').then(m => m.PendingAppointmentsComponent) },
      { path: 'appointments', loadComponent: () => import('./components/doctor/appointments.component').then(m => m.AppointmentsComponent) },
      { path: 'profile', loadComponent: () => import('./components/doctor/doctor-profile.component').then(m => m.DoctorProfileComponent) }
    ]
  },
  { path: '**', redirectTo: '' }
];
