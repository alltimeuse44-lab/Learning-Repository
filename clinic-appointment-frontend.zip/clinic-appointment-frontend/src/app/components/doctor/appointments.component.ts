import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-doctor-appointments',
  standalone: true,
  templateUrl: './appointments.component.html',
  styleUrls: ['./appointments.component.css'],
  imports: [CommonModule, FormsModule]
})
export class AppointmentsComponent implements OnInit {
  appointments: any[] = [];
  loading = false;
  errorMsg = '';

  selectedStatus: string = '';
  selectedDate: string = '';

  constructor(private http: HttpClient) {}

  ngOnInit() {
    this.fetchAppointments();
  }

  getDoctorId(): number | null {
    const doctorId = localStorage.getItem('doctorId');
    return doctorId ? parseInt(doctorId, 10) : null;
  }

  fetchAppointments() {
    this.loading = true;
    const doctorId = this.getDoctorId();
    if (!doctorId) {
      this.errorMsg = 'Doctor ID not found.';
      this.loading = false;
      return;
    }
    this.http.get<any[]>(`/api/appointments/doctor/${doctorId}/all`).subscribe({
      next: (res) => {
        this.appointments = (res || []).map(appt => ({
          ...appt,
          appointmentTime: new Date(appt.appointmentTime)
        }));
        this.loading = false;
      },
      error: () => {
        this.errorMsg = 'Failed to load appointments.';
        this.loading = false;
      }
    });
  }

  applyFilters() {
    const doctorId = this.getDoctorId();
    if (!doctorId) {
      this.errorMsg = 'Doctor ID not found.';
      return;
    }

    let url = `/api/appointments/doctor/${doctorId}/filter?`;
    if (this.selectedStatus) url += `status=${this.selectedStatus}&`;
    if (this.selectedDate) url += `date=${this.selectedDate}`;

    this.loading = true;
    this.http.get<any[]>(url).subscribe({
      next: (res) => {
        this.appointments = (res || []).map(appt => ({
          ...appt,
          appointmentTime: new Date(appt.appointmentTime)
        }));
        this.loading = false;
      },
      error: () => {
        this.errorMsg = 'Failed to apply filters.';
        this.loading = false;
      }
    });
  }

  resetFilters() {
    this.selectedStatus = '';
    this.selectedDate = '';
    this.fetchAppointments();
  }

  markAsCompleted(id: number) {
    this.http.put(`/api/appointments/${id}/complete`, {}).subscribe({
      next: () => {
        this.fetchAppointments(); // Refresh list after marking as completed
      },
      error: () => {
        alert('Failed to mark appointment as completed.');
      }
    });
  }
}
