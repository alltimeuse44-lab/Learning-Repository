import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-doctor-dashboard',
  standalone: true,
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css'],
  imports: [CommonModule, FormsModule]
})
export class DashboardComponent implements OnInit {
  stats = { total: 0, pending: 0, completed: 0, cancelled: 0 };
  loadingStats = false;
  errorMsg = '';
  pendingAppointments: any[] = [];
  upcomingAppointments: any[] = [];
  doctorName: string = 'Doctor';
  addedPatientId: number | null = null;

  constructor(private http: HttpClient, private router: Router) {}

  ngOnInit() {
    const doctorId = this.getDoctorId();
    if (doctorId !== null) {
      this.fetchDoctorName(doctorId);
      this.fetchStats(doctorId);
      this.fetchPendingAppointments(doctorId);
      this.fetchUpcomingAppointments(doctorId);
    } else {
      this.errorMsg = 'Doctor ID not found in local storage.';
    }
  }

  openPatientDetailsModal() {
    const modal = document.getElementById('patientDetailsModal');
    if (modal) {
      // @ts-ignore
      const bsModal = new (window as any).bootstrap.Modal(modal);
      bsModal.show();
    }
  }

  submitPatientDetails(form: any) {
    if (form.invalid) return;

    const payload = {
      name: form.value.name,
      email: form.value.email,
      phone: form.value.phone,
      role: 'PATIENT'  // Assuming backend differentiates by role
    };

    this.http.post<any>('/api/users', payload).subscribe({
      next: (res) => {
        this.addedPatientId = res.id;  // Save the new patient's ID
        // Close Patient Details Modal
        const modal = document.getElementById('patientDetailsModal');
        if (modal) {
          // @ts-ignore
          const bsModal = (window as any).bootstrap.Modal.getInstance(modal);
          if (bsModal) bsModal.hide();
        }
        // Open Book Appointment Modal next
        this.openBookAppointmentModal();
      },
      error: () => {
        this.errorMsg = 'Failed to save patient details.';
      }
    });
  }

  openBookAppointmentModal() {
    const modal = document.getElementById('bookAppointmentModal');
    if (modal) {
      // @ts-ignore
      const bsModal = new (window as any).bootstrap.Modal(modal);
      bsModal.show();
    }
  }

  submitBookAppointment(form: any) {
    if (form.invalid) return;

    const doctorId = this.getDoctorId();
    if (doctorId === null || this.addedPatientId === null) {
      this.errorMsg = 'Doctor ID or Patient ID is missing.';
      return;
    }

    const payload = {
      doctorId: doctorId,
      patientId: this.addedPatientId,
      appointmentTime: form.value.appointmentDate + 'T' + form.value.appointmentTime,
      description: form.value.description
    };

    this.http.post('/api/appointments?isDoctorBooking=true', payload).subscribe({
      next: () => {
        this.fetchStats(doctorId);
        this.fetchUpcomingAppointments(doctorId);

        // Hide Book Appointment Modal
        const modal = document.getElementById('bookAppointmentModal');
        if (modal) {
          // @ts-ignore
          const bsModal = (window as any).bootstrap.Modal.getInstance(modal);
          if (bsModal) bsModal.hide();
        }

        form.resetForm();
        this.errorMsg = '';
        this.addedPatientId = null;
        alert('Appointment booked successfully');
      },
      error: () => {
        this.errorMsg = 'Failed to book appointment.';
      }
    });
  }

  fetchDoctorName(doctorId: number) {
    this.http.get<any>(`http://localhost:8080/api/users/${doctorId}`).subscribe({
      next: (res) => {
        this.doctorName = res.name || 'Doctor';
      },
      error: () => {
        console.error('Failed to fetch doctor name.');
        this.doctorName = 'Doctor';
      }
    });
  }

  fetchStats(doctorId: number) {
    this.loadingStats = true;
    this.http.get<any>(`/api/appointments/doctor/${doctorId}/stats`).subscribe({
      next: (res) => {
        this.stats = {
          total: res.total || 0,
          pending: res.pending || 0,
          completed: res.completed || 0,
          cancelled: res.cancelled || 0
        };
        this.loadingStats = false;
      },
      error: () => {
        this.errorMsg = 'Failed to load stats.';
        this.loadingStats = false;
      }
    });
  }

  fetchPendingAppointments(doctorId: number) {
    this.http.get<any[]>(`/api/appointments/doctor/${doctorId}/pending`).subscribe({
      next: (res) => {
        this.pendingAppointments = res;
      },
      error: () => {
        this.errorMsg = 'Failed to load pending appointments.';
      }
    });
  }

  fetchUpcomingAppointments(doctorId: number) {
    this.http.get<any[]>(`/api/appointments/doctor/${doctorId}/upcoming`).subscribe({
      next: (res) => {
        this.upcomingAppointments = res;
      },
      error: () => {
        this.errorMsg = 'Failed to load upcoming appointments.';
      }
    });
  }

  approveAppointment(id: number) {
    const doctorId = this.getDoctorId();
    if (doctorId === null) {
      this.errorMsg = 'Doctor ID not found.';
      return;
    }

    this.http.put(`/api/appointments/${id}/approve`, {}).subscribe({
      next: () => {
        this.fetchPendingAppointments(doctorId);
        this.fetchStats(doctorId);
      },
      error: () => {
        this.errorMsg = 'Failed to approve appointment.';
      }
    });
  }

  rejectAppointment(id: number) {
    const doctorId = this.getDoctorId();
    if (doctorId === null) {
      this.errorMsg = 'Doctor ID not found.';
      return;
    }

    this.http.put(`/api/appointments/${id}/reject`, {}).subscribe({
      next: () => {
        this.fetchPendingAppointments(doctorId);
        this.fetchStats(doctorId);
      },
      error: () => {
        this.errorMsg = 'Failed to reject appointment.';
      }
    });
  }

  getDoctorId(): number | null {
    const doctorIdStr = localStorage.getItem('doctorId');
    if (doctorIdStr) {
      const parsedId = parseInt(doctorIdStr, 10);
      return isNaN(parsedId) ? null : parsedId;
    }
    return null;
  }

  goToPendingApprovals() {
    this.router.navigate(['/doctor/pending-appointments']);
  }
}
