import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-doctor-profile',
  standalone: true,
  templateUrl: './doctor-profile.component.html',
  styleUrls: ['./doctor-profile.component.css'],
  imports: [CommonModule, ReactiveFormsModule]
})
export class DoctorProfileComponent implements OnInit {
  profileForm: FormGroup;
  loading = false;
  successMsg = '';
  errorMsg = '';

  constructor(private fb: FormBuilder, private http: HttpClient) {
    this.profileForm = this.fb.group({
      name: ['', Validators.required],
      specialization: ['', Validators.required],
      bio: ['']
    });
  }

  ngOnInit() {
    this.fetchDoctorDetails();
  }

  getDoctorId() {
    const token = localStorage.getItem('jwtToken');
    if (!token) return null;
    try {
      const payload = JSON.parse(atob(token.split('.')[1]));
      return payload.doctorId || payload.id || null;
    } catch {
      return null;
    }
  }

  fetchDoctorDetails() {
    this.loading = true;
    const doctorId = this.getDoctorId();
    this.http.get<any>(`/api/doctors/${doctorId}`).subscribe({
      next: (res) => {
        this.profileForm.patchValue({
          name: res.name,
          specialization: res.specialization,
          bio: res.bio
        });
        this.loading = false;
      },
      error: () => {
        this.errorMsg = 'Failed to load doctor details.';
        this.loading = false;
      }
    });
  }

  updateDoctorDetails() {
    if (this.profileForm.invalid) return;
    this.loading = true;
    const doctorId = this.getDoctorId();
    this.http.put(`/api/doctors/${doctorId}`, this.profileForm.value).subscribe({
      next: () => {
        this.successMsg = 'Profile updated successfully!';
        this.loading = false;
      },
      error: () => {
        this.errorMsg = 'Failed to update profile.';
        this.loading = false;
      }
    });
  }
}
