import { Component, OnInit } from '@angular/core';
import { AppointmentsService } from '../../services/appointments.service';
import { CommonModule } from '@angular/common';
import { Router, RouterModule } from '@angular/router';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-doctor',
  standalone: true,
  templateUrl: './doctor.component.html',
  styleUrls: ['./doctor.component.css'],
  imports: [CommonModule, RouterModule]
})
export class DoctorComponent implements OnInit {
  bookedPatientCount: number = 0;
  appointments: any[] = [];
  loading = false;
  errorMsg = '';

  stats = { total: 0, pending: 0, upcoming: 0, completed: 0, cancelled: 0 };
  loadingStats = false;

  constructor(
    private appointmentsService: AppointmentsService,
    private router: Router,
    private http: HttpClient
  ) {}

  ngOnInit() {
    this.fetchStats();
  }

  fetchStats() {
    this.loadingStats = true;
    const doctorId = this.getDoctorId();
    if (doctorId === null) {
      this.errorMsg = 'Doctor ID not found.';
      this.loadingStats = false;
      return;
    }
    console.log('Fetching stats for doctor ID:', doctorId);
    this.http.get<any>(`/api/appointments/doctor/${doctorId}/stats`).subscribe({
      next: (res) => {
        this.stats = {
          total: res.total || 0,
          pending: res.pending || 0,
          upcoming: res.upcoming || 0,
          completed: res.completed || 0,
          cancelled: res.cancelled || 0
        };
        this.loadingStats = false;
      },
      error: () => {
        this.errorMsg = 'Failed to load stats.';
        this.loadingStats = false;
      }
    });
  }

  getDoctorId(): number | null {
    const doctorIdStr = localStorage.getItem('doctorId');
    console.log('Doctor ID from localStorage:', doctorIdStr);
    if (doctorIdStr) {
      const parsedId = parseInt(doctorIdStr, 10);
      return isNaN(parsedId) ? null : parsedId;
    }
    return null;
  }

  goToPendingApprovals() {
    this.router.navigate(['/doctor/pending-appointments']);
  }

  logout() {
    localStorage.removeItem('jwtToken');
    localStorage.removeItem('userRole');
    localStorage.removeItem('doctorId');
    this.router.navigate(['/login']);
  }
}
