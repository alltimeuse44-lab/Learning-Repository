import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { AppointmentsService } from '../../services/appointments.service';

@Component({
  selector: 'app-pending-appointments',
  standalone: true,
  templateUrl: './pending-appointments.component.html',
  styleUrls: ['./pending-appointments.component.css'],
  imports: [CommonModule]
})
export class PendingAppointmentsComponent implements OnInit {
  pendingAppointments: any[] = [];
  loading = false;
  errorMsg = '';
  successMsg = '';

  constructor(
    private http: HttpClient,
    private router: Router,
    private appointmentsService: AppointmentsService
  ) {}

  ngOnInit() {
    this.fetchPendingAppointments();
  }

  getDoctorId(): number | null {
    const doctorIdStr = localStorage.getItem('doctorId');
    if (doctorIdStr) {
      const parsedId = parseInt(doctorIdStr, 10);
      return isNaN(parsedId) ? null : parsedId;
    }
    return null;
  }

  fetchPendingAppointments() {
    this.loading = true;
    const doctorId = this.getDoctorId();

    if (doctorId === null) {
      this.errorMsg = 'Doctor ID not found.';
      this.loading = false;
      return;
    }

    this.http.get<any[]>(`/api/appointments/doctor/${doctorId}/pending`).subscribe({
      next: (res) => {
        this.pendingAppointments = res || [];
        this.loading = false;
      },
      error: () => {
        this.errorMsg = 'Failed to load pending appointments.';
        this.loading = false;
      }
    });
  }

  approveAppointment(id: number) {
    this.appointmentsService.approveAppointment(id).subscribe({
      next: () => {
        this.successMsg = 'Appointment approved!';
        this.fetchPendingAppointments();
      },
      error: () => {
        this.errorMsg = 'Failed to approve appointment.';
      }
    });
  }

  rejectAppointment(id: number) {
    this.appointmentsService.rejectAppointment(id).subscribe({
      next: () => {
        this.successMsg = 'Appointment rejected!';
        this.fetchPendingAppointments();
      },
      error: () => {
        this.errorMsg = 'Failed to reject appointment.';
      }
    });
  }
}
