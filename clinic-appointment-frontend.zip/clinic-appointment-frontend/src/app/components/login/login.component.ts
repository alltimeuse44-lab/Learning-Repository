import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { AuthService } from '../../services/auth.service';
import { jwtDecode } from 'jwt-decode';
import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';

@Component({
  selector: 'app-login',
  standalone: true,
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
  imports: [CommonModule, ReactiveFormsModule, HttpClientModule, RouterLink]
})
export class LoginComponent {
  loginForm: FormGroup;
  errorMsg: string = '';

  constructor(
    private fb: FormBuilder,
    private authService: AuthService,
    private router: Router
  ) {
    this.loginForm = this.fb.group({
      username: ['', Validators.required],
      password: ['', Validators.required]
    });
  }

  login() {
    if (this.loginForm.invalid) return;
    const { username, password } = this.loginForm.value;
    this.authService.login({ username, password }).subscribe({
      next: (res: any) => {
        // console.log('Login response:', res);
        const token = res.token;
        localStorage.setItem('jwtToken', token);
        const decoded: any = jwtDecode(token);
        let role = decoded.role || decoded.roles?.[0];
        if (role && role.startsWith('ROLE_')) role = role.replace('ROLE_', '');
        console.log('Decoded role:', role);
        localStorage.setItem('userRole', role);
        if (res.doctorId) {
        localStorage.setItem('doctorId', res.doctorId);
        }
        console.log('Doctor ID:', res.doctorId);
        if (role === 'ADMIN') this.router.navigate(['/dashboard-admin']);
        else if (role === 'DOCTOR') this.router.navigate(['/doctor']);
        else if (role === 'PATIENT') this.router.navigate(['/patient']);
        else this.router.navigate(['/dashboard-admin']);
      },
      error: (err: any) => {
        this.errorMsg = err.error?.message || 'Login failed. Please try again.';
      }
    });
  }
}
