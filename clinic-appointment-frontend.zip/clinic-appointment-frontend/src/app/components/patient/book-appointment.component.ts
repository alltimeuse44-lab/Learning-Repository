import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Router } from '@angular/router';
import { UserService } from '../../services/user.service';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';

@Component({
  selector: 'app-book-appointment',
  standalone: true,
  templateUrl: './book-appointment.component.html',
  styleUrls: ['./book-appointment.component.css'],
  imports: [CommonModule, ReactiveFormsModule]
})
export class BookAppointmentComponent implements OnInit {
  bookForm: FormGroup;
  doctors: any[] = [];
  slots: any[] = [];
  filteredSlots: any[] = [];
  loadingDoctors = false;
  loadingSlots = false;
  successMsg = '';
  errorMsg = '';

  constructor(
    private fb: FormBuilder,
    private http: HttpClient,
    private router: Router,
    private userService: UserService
  ) {
    this.bookForm = this.fb.group({
      doctorId: ['', Validators.required],
      date: ['', Validators.required],
      time: ['', Validators.required],
      description: ['', Validators.required]
    });
  }

  ngOnInit() {
    this.fetchDoctors();
  }

  fetchDoctors() {
    this.loadingDoctors = true;
    this.userService.getAllDoctors().subscribe({
      next: (res) => {
        this.doctors = res;
        this.loadingDoctors = false;
      },
      error: () => {
        this.errorMsg = 'Failed to load doctors.';
        this.loadingDoctors = false;
      }
    });
  }

  onDoctorChange() {
    const doctorId = this.bookForm.get('doctorId')?.value;
    if (!doctorId) {
      this.slots = [];
      this.filteredSlots = [];
      return;
    }
    this.loadingSlots = true;
    this.http.get<any[]>(`/api/schedules/doctor/${doctorId}`).subscribe({
      next: (res) => {
        this.slots = res;
        this.filteredSlots = [];
        this.loadingSlots = false;
      },
      error: (err) => {
        this.errorMsg = 'Failed to load schedule slots.';
        this.loadingSlots = false;
      }
    });
  }

  onDateChange() {
    const selectedDate = this.bookForm.get('date')?.value;
    if (!selectedDate) {
      this.filteredSlots = [];
      return;
    }
    this.filteredSlots = this.slots.filter(slot => slot.availableDate === selectedDate && slot.isAvailable);
  }

  getPatientId() {
    const token = localStorage.getItem('jwtToken');
    if (!token) return null;
    try {
      const payload = JSON.parse(atob(token.split('.')[1]));
      return payload.userId || payload.id || null;
    } catch {
      return null;
    }
  }

  bookAppointment() {
    if (this.bookForm.invalid) return;

    const patientId = this.getPatientId();
    if (!patientId) {
      this.errorMsg = 'Patient not authenticated.';
      return;
    }

    const { doctorId, date, time, description } = this.bookForm.value;

    const selectedSlot = this.filteredSlots.find(slot => slot.id == time);
    if (!selectedSlot) {
      this.errorMsg = 'Invalid time slot selected.';
      return;
    }

    const appointmentTime = `${selectedSlot.availableDate}T${selectedSlot.startTime}`;
    const endTime = `${selectedSlot.availableDate}T${selectedSlot.endTime}`;
    const slotId = selectedSlot.id;
    console.log(slotId)
    const payload = {
      patientId,
      doctorId,
      slotId,
      appointmentTime,
      endTime,
      description
    };

    this.http.post('/api/appointments', payload).subscribe({
      next: () => {
        // After successful booking, update slot availability to false
        this.updateSlotAvailability(selectedSlot.id);
      },
      error: () => {
        this.errorMsg = 'Failed to book appointment.';
      }
    });
  }

  updateSlotAvailability(slotId: number) {
    const token = localStorage.getItem('jwtToken');
const headers = new HttpHeaders().set('Authorization', `Bearer ${token}`);
    this.http.put(`/api/schedules/${slotId}/availability?isAvailable=false`, {}, { headers }).subscribe({
      next: () => {
        this.successMsg = 'Appointment booked successfully!';
        setTimeout(() => this.router.navigate(['/patient/appointments']), 1500);
      },
      error: () => {
        this.errorMsg = 'Failed to update slot availability.';
      }
    });
  }
}
