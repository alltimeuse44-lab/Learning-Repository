import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';

@Component({
  selector: 'app-my-appointments',
  standalone: true,
  templateUrl: './my-appointments.component.html',
  styleUrls: ['./my-appointments.component.css'],
  imports: [CommonModule]
})
export class MyAppointmentsComponent implements OnInit {
  appointments: any[] = [];
  upcoming: any[] = [];
  past: any[] = [];
  loading = false;
  errorMsg = '';
  showToast = false;
  toastMsg = '';

  constructor(private http: HttpClient, private router: Router) {}

  ngOnInit() {
    this.fetchAppointments();
  }

  getPatientId() {
    const token = localStorage.getItem('jwtToken');
    if (!token) return null;
    try {
      const payload = JSON.parse(atob(token.split('.')[1]));
      return payload.userId || payload.id || null;
    } catch {
      return null;
    }
  }

  fetchAppointments() {
    this.loading = true;
    const patientId = this.getPatientId();
    if (!patientId) {
      this.errorMsg = 'Patient not authenticated.';
      this.loading = false;
      return;
    }
    this.http.get<any[]>(`/api/appointments?patientId=${patientId}`).subscribe({
      next: (res) => {
        // Filter appointments by patientId in case backend does not
        this.appointments = (res || []).filter(a => a.patientId == patientId);
        this.splitAppointments();
        this.loading = false;
      },
      error: () => {
        this.errorMsg = 'Failed to load appointments.';
        this.loading = false;
      }
    });
  }

  splitAppointments() {
    // Upcoming: status PENDING or BOOKED
    this.upcoming = this.appointments.filter(a => a.status === 'PENDING' || a.status === 'BOOKED');
    // Past: status CANCELLED or COMPLETED
    this.past = this.appointments.filter(a => a.status === 'CANCELLED' || a.status === 'COMPLETED');
  }

  confirmCancel(appointment: any) {
    if (window.confirm('Are you sure you want to cancel this appointment?')) {
      this.cancelAppointment(appointment.id);
    }
  }

  cancelAppointment(appointmentId: number) {
    this.loading = true;
    this.http.put(`/api/appointments/${appointmentId}/cancel`, {}).subscribe({
      next: () => {
        this.showToastMsg('Appointment cancelled successfully!');
        this.fetchAppointments();
      },
      error: () => {
        this.showToastMsg('Failed to cancel appointment.');
        this.loading = false;
      }
    });
  }

  showToastMsg(msg: string) {
    this.toastMsg = msg;
    this.showToast = true;
    setTimeout(() => {
      this.showToast = false;
    }, 2000);
  }
}
