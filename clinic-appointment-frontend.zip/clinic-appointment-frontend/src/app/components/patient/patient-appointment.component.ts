import { Component, OnInit } from '@angular/core';
import { AppointmentsService } from '../../services/appointments.service';
import { UserService } from '../../services/user.service';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { NavbarComponent } from '../shared/navbar/navbar.component';

@Component({
  selector: 'app-patient-appointment',
  standalone: true,
  templateUrl: './patient-appointment.component.html',
  styleUrls: ['./patient-appointment.component.css'],
  imports: [CommonModule, ReactiveFormsModule, NavbarComponent]
})
export class PatientAppointmentComponent implements OnInit {
  doctors: any[] = [];
  bookForm: FormGroup;
  successMsg = '';
  errorMsg = '';
  loading = false;

  constructor(
    private userService: UserService,
    private appointmentsService: AppointmentsService,
    private fb: FormBuilder,
    private router: Router
  ) {
    this.bookForm = this.fb.group({
      doctorId: ['', Validators.required],
      date: ['', Validators.required],
      time: ['', Validators.required]
    });
  }

  ngOnInit() {
    this.loadDoctors();
  }

  loadDoctors() {
    this.loading = true;
    this.userService.getAllUsers().subscribe({
      next: (res: any) => {
        this.doctors = res.filter((u: any) => u.role === 'DOCTOR');
        this.loading = false;
      },
      error: () => {
        this.errorMsg = 'Failed to load doctors.';
        this.loading = false;
      }
    });
  }

  bookAppointment() {
    if (this.bookForm.invalid) return;
    this.appointmentsService.bookAppointment(this.bookForm.value).subscribe({
      next: () => {
        this.successMsg = 'Appointment booked successfully!';
        setTimeout(() => this.router.navigate(['/dashboard-patient']), 1500);
      },
      error: () => {
        this.errorMsg = 'Failed to book appointment.';
      }
    });
  }
}
