import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { CommonModule, DatePipe } from '@angular/common';

@Component({
  selector: 'app-patient-dashboard',
  standalone: true,
  templateUrl: './patient-dashboard.component.html',
  styleUrls: ['./patient-dashboard.component.css'],
  imports: [CommonModule, DatePipe]
})
export class PatientDashboardComponent implements OnInit {
  upcomingAppointments: any[] = [];
  stats = { total: 0, upcoming: 0, completed: 0, cancelled: 0 };
  loadingAppointments = false;
  loadingStats = false;
  errorMsg = '';
  patientName: string = '';

  constructor(private http: HttpClient, private router: Router) {}

  ngOnInit() {
    this.setPatientName();
    this.fetchStats();
    this.fetchUpcomingAppointments();

  }

  setPatientName() {
    const token = localStorage.getItem('jwtToken');
    if (token) {
      try {
        const payload = JSON.parse(atob(token.split('.')[1]));
        this.patientName = payload.sub || payload.username || 'Patient';
      } catch {
        this.patientName = 'Patient';
      }
    }
  }

  getPatientId() {
    const token = localStorage.getItem('jwtToken');
    if (!token) return null;
    try {
      const payload = JSON.parse(atob(token.split('.')[1]));
      return payload.userId || payload.id || null;
    } catch {
      return null;
    }
  }

  fetchStats() {
    this.loadingStats = true;
    const patientId = this.getPatientId();
    if (!patientId) return;
    this.http.get<any>(`/api/appointments/patient/${patientId}/stats`).subscribe({
      next: (res) => {
        this.stats = {
          total: res.total || 0,
          upcoming: res.upcoming || 0,
          completed: res.completed || 0,
          cancelled: res.cancelled || 0
        };
        this.loadingStats = false;
      },
      error: () => {
        this.loadingStats = false;
      }
    });
  }

  fetchUpcomingAppointments() {
    this.loadingAppointments = true;
    const patientId = this.getPatientId();
    if (!patientId) return;
    this.http.get<any[]>(`/api/appointments/patient/${patientId}/upcoming`).subscribe({
      next: (res) => {
        this.upcomingAppointments = res || [];
        this.loadingAppointments = false;
      },
      error: () => {
        this.errorMsg = 'Failed to load upcoming appointments.';
        this.loadingAppointments = false;
      }
    });
  }

  goToBookAppointment() {
    this.router.navigate(['/patient/book']);
  }

  goToViewAppointments() {
    this.router.navigate(['/patient/appointments']);
  }
}
