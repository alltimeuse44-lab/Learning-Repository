import { Component, OnInit } from '@angular/core';
import { AppointmentsService } from '../../services/appointments.service';
import { UserService } from '../../services/user.service';
import { CommonModule } from '@angular/common';
import { NavbarComponent } from '../shared/navbar/navbar.component';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { BookAppointmentComponent } from './book-appointment.component';
import { MyAppointmentsComponent } from './my-appointments.component';
import { EditProfileComponent } from './edit-profile.component';
import { RouterOutlet } from '@angular/router';

@Component({
  selector: 'app-patient',
  standalone: true,
  templateUrl: './patient.component.html',
  styleUrls: ['./patient.component.css'],
imports: [CommonModule, ReactiveFormsModule, NavbarComponent, RouterOutlet]
})
export class PatientComponent implements OnInit {
  activeTab: string = 'book';
  appointments: any[] = [];
  doctors: any[] = [];
  loading = false;
  errorMsg = '';
  showBookForm = false;
  bookForm: FormGroup;
  bookMsg = '';

  constructor(
    private appointmentsService: AppointmentsService,
    private userService: UserService,
    private fb: FormBuilder
  ) {
    this.bookForm = this.fb.group({
      doctorId: ['', Validators.required],
      date: ['', Validators.required],
      time: ['', Validators.required]
    });
  }

  logout() {
    localStorage.removeItem('jwtToken');
    localStorage.removeItem('userRole');
    window.location.href = '/login';
  }

  ngOnInit() {
    this.fetchAppointments();
    this.fetchDoctors();
  }


  fetchAppointments() {
    this.loading = true;
    this.appointmentsService.getAllAppointments().subscribe({
      next: (res: any) => {
        this.appointments = res;
        this.loading = false;
      },
      error: () => {
        this.loading = false;
      }
    });
  }

  fetchDoctors() {
    this.userService.getAllUsers().subscribe({
      next: (res: any) => {
        this.doctors = (res || []).filter((u: any) => u.role === 'DOCTOR');
      },
      error: () => {
        this.doctors = [];
      }
    });
  }

  openBookForm() {
    this.showBookForm = true;
    this.bookMsg = '';
    this.bookForm.reset();
  }

  closeBookForm() {
    this.showBookForm = false;
  }

  bookAppointment() {
    if (this.bookForm.invalid) return;
    this.appointmentsService.bookAppointment(this.bookForm.value).subscribe({
      next: () => {
        this.bookMsg = 'Appointment booked!';
        this.fetchAppointments();
        setTimeout(() => this.closeBookForm(), 1200);
      },
      error: () => {
        this.bookMsg = 'Failed to book appointment.';
      }
    });
  }

  cancelAppointment(appt: any) {
    this.appointmentsService.cancelAppointment(appt.id).subscribe({
      next: () => this.fetchAppointments(),
      error: () => alert('Failed to cancel appointment.')
    });
  }
}
