import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-toolbar',
  standalone: true,
  templateUrl: './toolbar.component.html',
  styleUrls: ['./toolbar.component.css'],
  imports: [CommonModule]
})
export class ToolbarComponent {
  @Input() userName: string = '';
  @Input() userRole: string = '';
  @Input() onLogout: () => void = () => {};
}
