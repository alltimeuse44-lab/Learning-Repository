import { Injectable } from '@angular/core';
import { CanActivate, Router } from '@angular/router';
import { AuthService } from '../services/auth.service';
import { jwtDecode } from 'jwt-decode';

@Injectable({ providedIn: 'root' })
export class AuthGuard implements CanActivate {
  constructor(private authService: AuthService, private router: Router) {}

  canActivate(route: any, state: any): boolean {
    const token = this.authService.getToken();
    if (!token) {
      this.router.navigate(['/login']);
      return false;
    }
    try {
      const decoded: any = jwtDecode(token);
      let userRole = decoded.role || decoded.roles?.[0];
      if (userRole && userRole.startsWith('ROLE_')) userRole = userRole.replace('ROLE_', '');
      // If route has data.roles, check if userRole matches
      if (route.data && route.data['roles'] && !route.data['roles'].includes(userRole)) {
        this.router.navigate(['/login']);
        return false;
      }
      return true;
    } catch {
      this.router.navigate(['/login']);
      return false;
    }
  }
}
