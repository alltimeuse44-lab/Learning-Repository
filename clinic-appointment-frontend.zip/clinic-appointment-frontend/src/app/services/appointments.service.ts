import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({ providedIn: 'root' })
export class AppointmentsService {
  private apiUrl = 'http://localhost:8080/api/appointments';

  constructor(private http: HttpClient) {}

  // Get all appointments (doctor view)
  getAllAppointments(): Observable<any> {
    return this.http.get(`${this.apiUrl}`);
  }

  // Get appointment by ID
  getAppointmentById(id: number): Observable<any> {
    return this.http.get(`${this.apiUrl}/${id}`);
  }

  // Book appointment
  bookAppointment(appointment: any): Observable<any> {
    return this.http.post(`${this.apiUrl}`, appointment);
  }

  // Cancel appointment
  cancelAppointment(id: number): Observable<any> {
    return this.http.put(`${this.apiUrl}/${id}/cancel`, {});
  }

  // Approve appointment
  approveAppointment(appointmentId: number): Observable<any> {
    return this.http.put(`${this.apiUrl}/${appointmentId}/approve`, {});
  }

  // Reject appointment
  rejectAppointment(appointmentId: number): Observable<any> {
    return this.http.put(`${this.apiUrl}/${appointmentId}/reject`, {});
  }
}
