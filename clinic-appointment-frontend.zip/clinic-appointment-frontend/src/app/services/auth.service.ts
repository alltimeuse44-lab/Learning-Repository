import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({ providedIn: 'root' })
export class AuthService {
  private apiUrl = 'http://localhost:8080/api/auth';

  constructor(private http: HttpClient) {}

  getToken(): string | null {
    return localStorage.getItem('jwtToken');
  }

  isLoggedIn(): boolean {
    return !!this.getToken();
  }

  getUserRole(): string {
    return localStorage.getItem('userRole') || '';
  }

  login(credentials: { username: string; password: string }): Observable<any> {
    // Backend expects username and password
    return this.http.post(`${this.apiUrl}/login`, credentials);
  }

  register(data: { name: string; email: string; password: string; role: string }): Observable<any> {
    // Backend expects username, email, password, role
    const payload = {
      username: data.name, // map name to username
      email: data.email,
      password: data.password,
      role: data.role
    };
    return this.http.post(`${this.apiUrl}/register`, payload);
  }
}
