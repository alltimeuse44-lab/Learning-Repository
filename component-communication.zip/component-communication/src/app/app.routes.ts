import { Routes } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { ScrivaniaItaliaComponent } from './scrivania-italia/scrivania-italia.component';
import { ScrivaniaEsteroComponent } from './scrivania-estero/scrivania-estero.component';

export const routes: Routes = [
  { path: '', redirectTo: 'login', pathMatch: 'full' },
  { path: 'login', component: LoginComponent },
  { path: 'scrivania-italia', component: ScrivaniaItaliaComponent },
  { path: 'scrivania-estero', component: ScrivaniaEsteroComponent }
];
