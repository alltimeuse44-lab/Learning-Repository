import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '../shared/auth.service';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [FormsModule],
  templateUrl: './login.component.html',
  styleUrl: './login.component.scss'
})
export class LoginComponent {
  name = '';
  role = '';

  constructor(private auth: AuthService, private router: Router) {}

  login() {
    if (this.name && this.role) {
      this.auth.login({ name: this.name, role: this.role });
      this.router.navigate(['/scrivania-italia']);
    }
  }
}
