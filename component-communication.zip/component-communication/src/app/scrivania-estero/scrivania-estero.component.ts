import { Component, OnInit, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TableComponent } from '../shared/table/table.component';
import { AuthService, UserDetails } from '../shared/auth.service';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-scrivania-estero',
  standalone: true,
  imports: [CommonModule, TableComponent],
  templateUrl: './scrivania-estero.component.html'
})
export class ScrivaniaEsteroComponent implements OnInit, OnDestroy {
  columns = ['ID', 'Client', 'Country', 'Amount', 'Status'];
  data = [
    { ID: 1, Client: 'John Smith',    Country: 'USA',     Amount: '$2500', Status: 'Active' },
    { ID: 2, Client: 'Emma Brown',    Country: 'UK',      Amount: '$1800', Status: 'Closed' },
    { ID: 3, Client: 'Hans Müller',   Country: 'Germany', Amount: '$3200', Status: 'Active' },
    { ID: 4, Client: 'Sophie Dupont', Country: 'France',  Amount: '$950',  Status: 'Pending' },
    { ID: 5, Client: 'Yuki Tanaka',   Country: 'Japan',   Amount: '$4100', Status: 'Active' }
  ];

  selectedRow: any = null;
  loggedUser: UserDetails | null = null;
  private sub!: Subscription;

  constructor(private auth: AuthService) {}

  ngOnInit() {
    this.loggedUser = this.auth.currentUser;
    this.sub = this.auth.user$.subscribe(u => this.loggedUser = u);
  }

  ngOnDestroy() {
    this.sub.unsubscribe();
  }

  onRowSelected(row: any) {
    this.selectedRow = row;
  }
}
