import { Component, OnInit, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TableComponent } from '../shared/table/table.component';
import { AuthService, UserDetails } from '../shared/auth.service';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-scrivania-italia',
  standalone: true,
  imports: [CommonModule, TableComponent],
  templateUrl: './scrivania-italia.component.html'
})
export class ScrivaniaItaliaComponent implements OnInit, OnDestroy {
  columns = ['ID', 'Cliente', 'Prodotto', 'Importo', 'Stato'];
  
  data = [
    { ID: 1, Cliente: 'Mario Rossi',    Prodotto: 'Laptop',  Importo: '€1200', Stato: 'Attivo' },
    { ID: 2, Cliente: 'Luca Bianchi',   Prodotto: 'Monitor', Importo: '€350',  Stato: 'Chiuso' },
    { ID: 3, Cliente: 'Anna Verdi',     Prodotto: 'Tastiera',Importo: '€80',   Stato: 'Attivo' },
    { ID: 4, Cliente: 'Sara Neri',      Prodotto: 'Mouse',   Importo: '€45',   Stato: 'Pendente' },
    { ID: 5, Cliente: 'Paolo Gialli',   Prodotto: 'Webcam',  Importo: '€95',   Stato: 'Attivo' }
  ];

  selectedRow: any = null;
  loggedUser: UserDetails | null = null;
  private sub!: Subscription;

  constructor(private auth: AuthService) {}

  ngOnInit() {
    this.loggedUser = this.auth.currentUser;
    this.sub = this.auth.user$.subscribe(u => this.loggedUser = u);
  }

  ngOnDestroy() {
    this.sub.unsubscribe();
  }

  onRowSelected(row: any) {
    this.selectedRow = row;
  }
}
