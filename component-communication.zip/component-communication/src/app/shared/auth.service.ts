import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';

export interface UserDetails {
  name: string;
  role: string;
}

@Injectable({ providedIn: 'root' })
export class AuthService {
  private userSubject = new Subject<UserDetails>();
  user$ = this.userSubject.asObservable();
  currentUser: UserDetails | null = null;

  login(user: UserDetails) {
    this.currentUser = user;
    this.userSubject.next(user);
  }
}
