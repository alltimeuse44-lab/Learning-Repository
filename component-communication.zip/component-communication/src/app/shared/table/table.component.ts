import { Component, Input, Output, EventEmitter, OnChanges } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-table',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './table.component.html',
  styleUrl: './table.component.scss'
})
export class TableComponent implements OnChanges {
  @Input() columns: string[] = [];
  @Input() data: any[] = [];
  
  @Output() rowSelected = new EventEmitter<any>();

  sortedData: any[] = [];
  sortColumn = '';
  sortAsc = true;

  ngOnChanges() {
    this.sortedData = [...this.data];
  }

  sort(col: string) {
    if (this.sortColumn === col) {
      this.sortAsc = !this.sortAsc;
    } else {
      this.sortColumn = col;
      this.sortAsc = true;
    }
    this.sortedData = [...this.data].sort((a, b) => {
      const valA = a[col];
      const valB = b[col];
      return this.sortAsc
        ? String(valA).localeCompare(String(valB))
        : String(valB).localeCompare(String(valA));
    });
  }

  selectRow(row: any) {
    this.rowSelected.emit(row);
  }
}
