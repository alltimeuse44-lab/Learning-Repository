import { Component, signal } from '@angular/core';
import { RouterOutlet } from '@angular/router';

@Component({
  selector: 'app-root',
  imports: [RouterOutlet],
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App {
  hasLogin = false;

  showBox=true;
  Toggle(){
    this.showBox = !this.showBox;
  }

  age = 0;
  updateAge(val : string){
    this.age = Number(val);
  }

  marks!: number;
  getMarks(val: number){
    this.marks = val;
  }

  section = "home";
  
  category='';
  findCategory(val: string){
    this.category= val.toLowerCase();
  }

  items = ['HTML', 'CSS', 'JavaScript', 'Angular'];

  users = [ 
    { name: 'Suhel', age: 24 },
    { name: 'Nikhil', age: 33 },
    { name: 'Suhas', age:  34},
    { name: 'Roshan', age: 45 },
  ]

  fruits = [ 'Apple', 'Banana', 'Cherry', 'Dates'];

  removeFruit(i: number){
    this.fruits.splice(i,1);  
  }

  nums = [1, 2, 3, 4, 5];
  
}
