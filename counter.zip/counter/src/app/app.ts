import { Component, signal } from '@angular/core';
import { RouterOutlet } from '@angular/router';

@Component({
  selector: 'app-root',
  imports: [RouterOutlet],
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App {
  // protected readonly title = signal('counter');

  count: number = 0;

  // increment(){
  //   this.count++;
  // }
  // decrement(){
  //   this.count--;
  // }
  // reset(){
  //   this.count=0;
  // }

  handle(value: string){
    if(value=="add"){
      this.count++;
    }
    else if(value=="substract"){
      this.count--;
    }
    else this.count = 0;
  }

  name = "";
  city = "";
  email = "";
  getName(value: string){
    this.name=value;
  }

  getEmail(val: string){
    this.email=val;
  }
}
