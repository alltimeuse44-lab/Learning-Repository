import { Component, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-component1',
  imports: [],
  templateUrl: './component1.html',
  styleUrl: './component1.css',
})

export class Component1 {
  @Input() name : string = "";
  @Input() age = "";

  
  @Output() sayHello = new EventEmitter<string>();
  sendData(){
    this.sayHello.emit("Hello parents");
  }
  
  



}
