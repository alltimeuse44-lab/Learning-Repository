import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { ProductHeaderComponent } from './product-header/product-header.component';
import { MainContentComponent } from './main-content/main-content.component';
import { ProductNavigationComponent } from './product-navigation/product-navigation.component';
import { FooterComponent } from './footer/footer.component';

@NgModule({
  declarations: [
    AppComponent,
    ProductHeaderComponent,
    MainContentComponent,
    ProductNavigationComponent,
    FooterComponent
  ],
  imports: [
    BrowserModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
