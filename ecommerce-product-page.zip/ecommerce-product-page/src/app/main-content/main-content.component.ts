import { Component } from '@angular/core';
import { Product } from '../product.model';

@Component({
  selector: 'app-main-content',
  templateUrl: './main-content.component.html',
  styleUrls: ['./main-content.component.css']
})
export class MainContentComponent {
  products: Product[] = [
    {
      id: 1,
      name: 'Wireless Headphones',
      brand: 'SoundWave',
      price: 129.99,
      description: 'Over-ear noise-canceling headphones with up to 30 hours of battery life.',
      image: 'assets/img1.jpg',
      features: ['Noise Cancellation', 'Bluetooth 5.2', 'Foldable Design'],
      specifications: {
        Battery: '30 hours',
        Connectivity: 'Bluetooth 5.2',
        Weight: '250g'
      }
    },
    {
      id: 2,
      name: 'Smartphone Pro',
      brand: 'Pixelix',
      price: 899.99,
      description: 'High-performance smartphone with a stunning OLED display and pro camera system.',
      image: 'assets/img2.jpg',
      features: ['6.7" OLED', 'Triple Camera', '128GB Storage'],
      specifications: {
        Display: '6.7" OLED',
        Storage: '128GB',
        Battery: '4200mAh'
      }
    },
    {
      id: 3,
      name: 'Smart LED TV',
      brand: 'VisionPlus',
      price: 699.99,
      description: '55-inch 4K HDR smart TV with built-in streaming apps and voice control.',
      image: 'assets/img3.jpg',
      features: ['4K UHD', 'HDR10+', 'Smart TV'],
      specifications: {
        Size: '55 inch',
        Resolution: '4K UHD',
        Smart: 'Yes'
      }
    },
    {
      id: 4,
      name: 'Digital Camera',
      brand: 'CapturePro',
      price: 499.99,
      description: 'Compact mirrorless camera with 4K video and interchangeable lens support.',
      image: 'assets/img4.jpg',
      features: ['4K Video', 'Interchangeable Lens', 'Wi-Fi'],
      specifications: {
        Sensor: '24MP',
        Video: '4K',
        Connectivity: 'Wi-Fi'
      }
    }
  ];
}
