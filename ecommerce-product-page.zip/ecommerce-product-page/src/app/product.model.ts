export interface Product {
  id: number;
  name: string;
  brand: string;
  price: number;
  description: string;
  image: string;
  features: string[];
  specifications: { [key: string]: string };
}