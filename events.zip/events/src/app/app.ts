import { Component, signal } from '@angular/core';
import { RouterOutlet } from '@angular/router';

@Component({
  selector: 'app-root',
  imports: [RouterOutlet],
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App {
  protected readonly title = signal('events');

  clickButton(){
    console.log("Clicked");
  }

  onTyping(any: any){
    console.log("Typing", any);
  }

  onKey(key : any){
    console.log("key", key);
  }

  onHover(){
    console.log("Hover Event");
  }

  leave(){
    console.log("Leave Event");
  }

  onBlur(){
    console.log("Blur Event");
  }
  
  onFocus(){
    console.log("Focus Event");
  }

}
