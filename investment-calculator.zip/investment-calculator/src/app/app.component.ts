import { Component } from '@angular/core';
// import { Component, signal } from '@angular/core';
import { HeaderComponent } from './header/header.component';
import { UserInputComponent } from "./user-input/user-input.component";
// import { InvestmentInput } from './investment.input.model';
import { InvestmentResultsComponent } from "./investment-results/investment-results.component";

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [HeaderComponent, UserInputComponent, InvestmentResultsComponent],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  resultData?: {
    year: number;
    interest: number;
    valueEndOfYear: number;
    annualInvestment: number;
    totalInterest: number;
    totalAmountInvested: number;
  }[];

  // *****-----------********

  // resultData = signal<{
  //   year: number; 
  //   interest: number; 
  //   valueEndOfYear: number; 
  //   annualInvestment: number; 
  //   totalInterest: number; 
  //   totalAmountInvested: number;
  // }[] | undefined>(undefined);


  
  calculateInvestmentResults(data:InvestmentInput){
  // calculateInvestmentResults(data:{initialInvestment: number; annualInvestment: number; expectedReturn: number; duration: number;}){

    const { initialInvestment, annualInvestment, expectedReturn, duration } = data;
    const annualData = [];
    let investmentValue = initialInvestment;

    for (let i=0; i<duration; i++){
      const year = i + 1;
      const interestEarnedInYear = investmentValue * (expectedReturn / 100);
      investmentValue += interestEarnedInYear + annualInvestment;
      const totalInterest = investmentValue - annualInvestment * year - initialInvestment;
      annualData.push({ 
        year: year, 
        interest: interestEarnedInYear,
        valueEndOfYear: investmentValue,
        annualInvestment: annualInvestment,
        totalInterest: totalInterest,
        totalAmountInvested: initialInvestment + annualInvestment * year,
      });
    } 
    // console.log(annualData);
    // this.resultData= annualData;
    this.resultData.set(annualData);
  }
}
