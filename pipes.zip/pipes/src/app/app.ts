import { CommonModule } from '@angular/common';
import { Component, signal } from '@angular/core';
import { PipeShortNamePipe } from './pipe/pipe-short-name-pipe';
import { ConvertPipe } from './pipe/convert-pipe';

@Component({
  selector: 'app-root',
  imports: [CommonModule, PipeShortNamePipe, ConvertPipe],
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App {
  lName = "suhel";
  uName = "SUHEL";

  today = new Date();
  amount = 2500;

  per = 0.34

  name= "Suhel Shaikh";
  
  usd = 10;
  usdToInr = 95;
}
