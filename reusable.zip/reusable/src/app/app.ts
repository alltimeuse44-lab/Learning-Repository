import { Component, signal } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { Card } from './card/card';
import { Button } from './button/button';

@Component({
  selector: 'app-root',
  imports: [RouterOutlet, Card, Button],
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App {
  saveData(){
    console.log("fetch data");
  }

  message="";
  OnSave(msg : string){
    console.log(msg);
    this.message= msg; 
  }
}
