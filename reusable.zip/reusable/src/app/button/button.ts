import { Component, input, output } from '@angular/core';

@Component({
  selector: 'app-button',
  imports: [],
  templateUrl: './button.html',
  styleUrl: './button.css',
})
export class Button {
  label = input<string>();
  clicked = output<string>();

  Onclick(){
    console.log("Card button clicked(Child)");
    this.clicked.emit("Button clicked successfully");
  }
}

