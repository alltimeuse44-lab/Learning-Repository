import { Component, signal } from '@angular/core';
import { RouterLink, RouterOutlet } from '@angular/router';
// import {Home } from './home/home';
// import {About } from './about/about';
// import {Contact } from './contact/contact';
// import { HeaderComponent } from './header/header';


@Component({
  selector: 'app-root',
  imports: [RouterOutlet, RouterLink ],
  templateUrl: './app.html',
  styleUrl: './app.css'
})

export class App {
  protected readonly title = signal('routing');

  name="Angular";

  getCity(){
    return "bangalore";
  }

  val= signal("Assining value using signal");
}
