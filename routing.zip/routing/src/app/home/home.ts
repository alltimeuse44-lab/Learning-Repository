import { Component } from '@angular/core';
import { signal } from '@angular/core';

@Component({
  selector: 'app-home',
  imports: [],
  templateUrl: './home.html',
  styleUrl: './home.css',
})
export class Home {

  imageUrl = "https://media.istockphoto.com/id/1917491709/photo/aerial-view-of-green-forests-with-earth-green-planet-in-your-hands-save-earth-texture-of.jpg?s=612x612&w=0&k=20&c=D-AGawRjdqcBkV_6bO9Y-HPToD3JfrIXnmSnUpuX-oA=";
  isDisabled = false;
  isActive = false;

  num = signal(0);

  count = 0;
  increment(){
    this.count++;
  }

  showEvent(e: any){
    console.log(e);
  }

  username='';
  updateUser(newName: string){
    return this.username = newName;
  }


}
