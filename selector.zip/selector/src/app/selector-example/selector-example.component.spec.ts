import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SelectorExampleComponent } from './selector-example.component';

describe('SelectorExampleComponent', () => {
  let component: SelectorExampleComponent;
  let fixture: ComponentFixture<SelectorExampleComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SelectorExampleComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(SelectorExampleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
