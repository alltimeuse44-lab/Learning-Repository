import { Component, ElementRef, ViewChild, Renderer2 } from '@angular/core';

@Component({
  selector: 'app-selector-example',
  templateUrl: './selector-example.component.html',
  styleUrls: ['./selector-example.component.css']
})

export class SelectorExampleComponent {
  items : string[] = ['Item 1', 'Item 2', 'Item 3'];
  count: number = 0;


  @ViewChild('box', { static: false }) boxRef!: ElementRef;

  constructor(private renderer: Renderer2) {}

  changeText() {
    const paragraph = document.querySelector('#paragraph');
    if(paragraph){
      paragraph.textContent = 'Text has been changed';
    }
    
    this.renderer.setStyle(this.boxRef.nativeElement, 'backgroundColor', 'blue');
    
    this.renderer.addClass(this.boxRef.nativeElement, "highlight");
  }

  onclick(){
    console.log(++this.count);
  }
}

