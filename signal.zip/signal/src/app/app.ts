import { Component, signal, computed } from '@angular/core';

interface User {
  name: string,
  age: number
}

@Component({
  selector: 'app-root',
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App {

count = signal(5);

increment(){
  this.count.update(c => c + 5);
}
decrement(){
  this.count.update(c=>c-5);
}
reset(){
  this.count.set(0);
}

bool = signal<boolean>(true);
str = signal<string>('Angular');
num = signal<number>(4);

numbers = signal<number[]>([8, 3, 9, 2, 5]);

user=signal<User>({ name: 'Anup', age: 23 });

directUpdate(){
  this.numbers.set([100, 200, 300]);
}

addNumers(){
  this.numbers.update(arr => [...arr, 7, 4]);
}

doubleNum = computed<number>(()=> this.num() *2);
trippleNum = computed(()=> this.num() *3);

numIncrement(){
  this.num.set(this.num()+1);
}

firstName = signal('Suhel');
lastName = signal('Shaikh');

fullName = computed<string>(()=> `${this.firstName()} ${this.lastName()}`);

price = signal([10, 20, 30, 40, 50]);

total = computed<number>(()=> {
  return this.price().reduce((acc, curr) => acc+curr, 0);
});


}
