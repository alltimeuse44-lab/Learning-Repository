import { Component } from '@angular/core';
import { TodoList } from './todo-list/todo-list';
import { TodoDetails } from './todo-details/todo-details';

@Component({
  selector: 'app-root',
  imports: [TodoList, TodoDetails],
  templateUrl: './app.html',
  styleUrl: './app.scss'
})
export class App {}
