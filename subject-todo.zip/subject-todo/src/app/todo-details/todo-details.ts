import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TodoApi } from '../../services/todo-api';

@Component({
  selector: 'app-todo-details',
  imports: [CommonModule],
  templateUrl: './todo-details.html',
  styleUrl: './todo-details.scss',
})
export class TodoDetails {

  selected: any = null;
  con: any;

  private apiSrv = inject(TodoApi);

  ngOnInit(): void {
     this.con = this.apiSrv.task$.subscribe(task => {
      this.selected = task;
    });
  }

  close(): void {
    this.apiSrv.clearTask();
  }

  ngOnDestroy() {
    this.con.unsubscribe();
  }

}
