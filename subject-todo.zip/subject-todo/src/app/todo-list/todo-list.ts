import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TodoApi } from '../../services/todo-api';
import { FormControl, ReactiveFormsModule } from '@angular/forms';
import { debounceTime, distinctUntilChanged } from 'rxjs';

@Component({
  selector: 'app-todo-list',
  imports: [ReactiveFormsModule, CommonModule],
  templateUrl: './todo-list.html',
  styleUrl: './todo-list.scss',
})
export class TodoList {
  tasks: any[] = [];
  allTasks: any[] = [];
  searchControl = new FormControl();

  private apiSrv = inject(TodoApi);

  ngOnInit(): void {
    this.apiSrv.getTask().subscribe((res: any) => {
      this.allTasks = res.todos;
      this.tasks = this.allTasks;
    });

    this.searchControl.valueChanges.pipe(
      debounceTime(300),
      distinctUntilChanged()
    ).subscribe(item => {
      this.search(item || '');
    });
  }

  search(item: string) {
    this.tasks = this.allTasks.filter(task =>
      task.todo.toLowerCase().includes(item.toLowerCase())
    );
  }

  open(task: any): void {
    this.apiSrv.setTask(task);
  }
}
