import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { Subject } from 'rxjs';
import { inject } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class TodoApi {

  private taskSubject = new Subject<any | null>();
  task$ = this.taskSubject.asObservable();

  private http = inject(HttpClient);

  getTask(){
    return this.http.get<any[]>('https://dummyjson.com/todos?limit=0');
  }

  setTask(task : any): void{
    this.taskSubject.next(task);
  }

  clearTask(): void {
    this.taskSubject.next(null);
  }
  
}
