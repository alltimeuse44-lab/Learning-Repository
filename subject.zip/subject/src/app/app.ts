import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { UserProfileComponent } from './components/user-profile/user-profile.component';
import { NotificationPanelComponent } from './components/notification-panel/notification-panel.component';
import { UserService } from './services/user.service';
import { NotificationService } from './services/notification.service';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, FormsModule, UserProfileComponent, NotificationPanelComponent],
  templateUrl: './app.html',
  styleUrl: './app.scss'
})
export class App {
  loginName = '';
  loginEmail = '';

  constructor(
    public userService: UserService,
    public notificationService: NotificationService
  ) {}

  login() {
    if (!this.loginName || !this.loginEmail) return;
    this.userService.login(this.loginName, this.loginEmail);
    this.notificationService.sendNotification(`Welcome, ${this.loginName}!`, 'success');
    this.loginName = '';
    this.loginEmail = '';
  }

  logout() {
    const name = this.userService.getCurrentUser().name;
    this.userService.logout();
    this.notificationService.sendNotification(`${name} has logged out.`, 'warning');
  }

  makeAdmin() {
    this.userService.updateUser({ role: 'admin' });
    this.notificationService.sendNotification('User role upgraded to Admin!', 'info');
  }

  sendError() {
    this.notificationService.sendNotification('Something went wrong!', 'error');
  }
}
