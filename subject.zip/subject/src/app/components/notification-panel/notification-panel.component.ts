import { Component, OnInit, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Subscription } from 'rxjs';
import { NotificationService, Notification } from '../../services/notification.service';

@Component({
  selector: 'app-notification-panel',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './notification-panel.component.html',
  styleUrls: ['./notification-panel.component.scss']
})
export class NotificationPanelComponent implements OnInit, OnDestroy {
  notifications: Notification[] = [];
  private subscription?: Subscription;

  constructor(private notificationService: NotificationService) {}

  ngOnInit() {
    // Subject: Only receives notifications sent AFTER subscription
    this.subscription = this.notificationService.notification$.subscribe(notification => {
      this.notifications.unshift(notification);
      console.log('Notification received:', notification);
      
      // Auto-remove after 5 seconds
      setTimeout(() => this.removeNotification(notification.id), 5000);
    });
  }

  removeNotification(id: number) {
    this.notifications = this.notifications.filter(n => n.id !== id);
  }

  ngOnDestroy() {
    this.subscription?.unsubscribe();
  }
}
