import { Component, OnInit, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Subscription } from 'rxjs';
import { UserService, User } from '../../services/user.service';

@Component({
  selector: 'app-user-profile',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './user-profile.component.html',
  styleUrls: ['./user-profile.component.scss']
})
export class UserProfileComponent implements OnInit, OnDestroy {
  user: User | null = null;
  private subscription?: Subscription;

  constructor(private userService: UserService) {}

  ngOnInit() {
    // BehaviorSubject emits current value immediately to new subscribers
    this.subscription = this.userService.user$.subscribe(user => {
      this.user = user;
      console.log('User Profile received:', user);
    });
  }

  ngOnDestroy() {
    this.subscription?.unsubscribe();
  }
}
