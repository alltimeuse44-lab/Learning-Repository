import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';

export interface Notification {
  id: number;
  message: string;
  type: 'success' | 'error' | 'info' | 'warning';
}

@Injectable({
  providedIn: 'root'
})
export class NotificationService {
  // Subject: No initial value, only emits to subscribers AFTER subscription
  private notificationSubject = new Subject<Notification>();
  
  // Expose as observable (read-only)
  notification$ = this.notificationSubject.asObservable();

  private idCounter = 1;

  sendNotification(message: string, type: Notification['type'] = 'info') {
    const notification: Notification = {
      id: this.idCounter++,
      message,
      type
    };
    
    // Emit to all current subscribers
    this.notificationSubject.next(notification);
  }
}
