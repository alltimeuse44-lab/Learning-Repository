import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

export interface User {
  name: string;
  email: string;
  role: string;
  isOnline: boolean;
}

@Injectable({
  providedIn: 'root'
})
export class UserService {
  // BehaviorSubject: Requires initial value, emits current value to new subscribers immediately
  private userSubject = new BehaviorSubject<User>({
    name: 'Guest',
    email: 'guest@example.com',
    role: 'visitor',
    isOnline: false
  });

  // Expose as observable
  user$ = this.userSubject.asObservable();

  // Get current value synchronously (only BehaviorSubject has this)
  getCurrentUser(): User {
    return this.userSubject.getValue();
  }

  updateUser(user: Partial<User>) {
    const currentUser = this.userSubject.getValue();
    this.userSubject.next({ ...currentUser, ...user });
  }

  login(name: string, email: string) {
    this.updateUser({ name, email, role: 'user', isOnline: true });
  }

  logout() {
    this.userSubject.next({
      name: 'Guest',
      email: 'guest@example.com',
      role: 'visitor',
      isOnline: false
    });
  }
}
