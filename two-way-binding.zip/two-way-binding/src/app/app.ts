import { Component, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterOutlet } from '@angular/router';

@Component({
  selector: 'app-root',
  imports: [FormsModule],
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App {
  username="suhel";
  name= signal("Suhel");

  user = signal<{name: string, age: number}>({ 
    name : "Aditya", 
    age: 24 
  })

  updateName(val: string){
    this.user.update(user => ({ ...user, name: val}));
  }

  updateAge(){
    this.user.update(user=> ({ ...user, age: user.age+1}));
  }
}
